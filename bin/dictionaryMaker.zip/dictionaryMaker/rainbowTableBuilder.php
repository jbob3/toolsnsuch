<?php

$resFiles = scandir('res/');
$words = array();

foreach($resFiles as $file) {
    #echo $file . "\n";

    if(strpos($file, '.') !== 0){
        $scrapeFile = 'res/' . $file;
        $scrapeData = file($scrapeFile);
        $scrapeDataStr = implode("\n",$scrapeData);

        $words = str_word_count($scrapeDataStr, 1);

        if(count($words) > 0){
            $handle = fopen("wordlist.txt", 'a');
                if($handle){
                foreach($words as $word){
                    if(strlen($word) > 3) {
                        $word .= "\n";
                        fwrite($handle, $word);
                    }
                }
            }
            else {
                echo "Couldn't open the file to write to." . "\n";
            }
        }
        else {
            echo "There ain't no words in that array!" . "\n";
        }
    }
}

?>
